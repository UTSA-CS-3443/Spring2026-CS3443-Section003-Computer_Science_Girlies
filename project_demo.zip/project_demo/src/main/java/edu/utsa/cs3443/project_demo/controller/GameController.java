package edu.utsa.cs3443.project_demo.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

import javafx.stage.Stage;
import edu.utsa.cs3443.project_demo.model.Card;
import edu.utsa.cs3443.project_demo.model.Game;
import edu.utsa.cs3443.project_demo.model.Player;

import java.io.IOException;
import java.io.InputStream;

public class GameController {

    @FXML private Text turnLabel;
    @FXML private Button topCardDisplay;
    @FXML private HBox handContainer;
    @FXML private Button drawButton;

    private Game game;

    @FXML
    public void initialize() {
        game = new Game();

        // Temporary players until Lobby passes real players later
        Player player1 = new Player("Player 1", false);
        Player bot1 = new Player("Bot 1", true);

        game.addPlayer(player1);
        game.addPlayer(bot1);

        game.startGame(); // loads cards.csv + shuffles deck + deals cards

        updateUI();
    }

    @FXML
    private void handleDrawCard() {
        Player currentPlayer = game.getCurrentPlayer();

        currentPlayer.drawCard(game.getDeck());
        game.nextTurn();

        updateUI();
    }

    private void handlePlayCard(Card card) {
        Player currentPlayer = game.getCurrentPlayer();
        Card topCard = game.getTopCard();

        if (card.matches(topCard)) {
            currentPlayer.getHand().remove(card);
            game.getDiscardPile().push(card);

            game.nextTurn();
            updateUI();
        } else {
            System.out.println("Invalid move: " + card + " does not match " + topCard);
        }
    }

    private void updateUI() {
        Player currentPlayer = game.getCurrentPlayer();

        turnLabel.setText(currentPlayer.getName() + "'s Turn");

        updateTopCard();
        updatePlayerHand(currentPlayer);

        Player winner = game.checkWinner();
        if (winner != null) {
            turnLabel.setText(winner.getName() + " wins!");
            drawButton.setDisable(true);
            handContainer.setDisable(true);
        }
    }

    private void updateTopCard() {
        Card topCard = game.getTopCard();

        ImageView imageView = createCardImageView(topCard, 90, 130);

        topCardDisplay.setText("");
        topCardDisplay.setGraphic(imageView);
        topCardDisplay.setStyle("-fx-background-color: transparent;");
    }

    private void updatePlayerHand(Player currentPlayer) {
        handContainer.getChildren().clear();

        for (Card card : currentPlayer.getHand()) {
            Button cardButton = createCardButton(card);
            handContainer.getChildren().add(cardButton);
        }
    }

    private Button createCardButton(Card card) {
        Button cardButton = new Button();

        ImageView imageView = createCardImageView(card, 70, 100);

        cardButton.setGraphic(imageView);
        cardButton.setStyle("-fx-background-color: transparent;");

        // Hover effect
        cardButton.setOnMouseEntered(event -> {
            cardButton.setTranslateY(-10);
            cardButton.setScaleX(1.15);
            cardButton.setScaleY(1.15);
        });

        cardButton.setOnMouseExited(event -> {
            cardButton.setTranslateY(0);
            cardButton.setScaleX(1.0);
            cardButton.setScaleY(1.0);
        });

        cardButton.setOnAction(event -> handlePlayCard(card));

        return cardButton;
    }

    private ImageView createCardImageView(Card card, double width, double height) {
        String imagePath = "/images/cards/"
                + card.getColor().toLowerCase()
                + "_"
                + card.getValue().toLowerCase()
                + ".png";

        InputStream stream = getClass().getResourceAsStream(imagePath);

        if (stream == null) {
            System.out.println("Missing image: " + imagePath);

            // Fallback empty image view so app does not crash
            ImageView fallback = new ImageView();
            fallback.setFitWidth(width);
            fallback.setFitHeight(height);
            return fallback;
        }

        Image image = new Image(stream);
        ImageView imageView = new ImageView(image);

        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        imageView.setPreserveRatio(true);

        return imageView;
    }

    private void switchScene(ActionEvent event, String fxmlPath) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            double width = stage.getScene().getWidth();
            double height = stage.getScene().getHeight();

            Scene scene = new Scene(root, width, height);
            stage.setScene(scene);

            // Optional: keep maximized/fullscreen if already set
            stage.setMaximized(true);

            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handlePlayGame(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/lobby.fxml");
    }

    @FXML
    private void handleSettings(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/settings.fxml");
    }

    @FXML
    private void handleHowToPlay(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/how_to_play.fxml");
    }
}