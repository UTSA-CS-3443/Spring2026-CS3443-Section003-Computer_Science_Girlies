package edu.utsa.cs3443.project_demo.model;

import java.util.ArrayList;
import java.util.Stack;

public class Game {

    private ArrayList<Player> players;
    private Deck deck;
    private Stack<Card> discardPile;
    private int currentPlayerIndex;
    private int direction; // 1 = forward, -1 = reverse

    public Game() {
        players = new ArrayList<>();
        deck = new Deck();
        discardPile = new Stack<>();
        currentPlayerIndex = 0;
        direction = 1;
    }

    // Add player
    public void addPlayer(Player player) {
        players.add(player);
    }

    // Start game
    public void startGame() {
        deck.loadFromFile("src/main/resources/data/cards.csv");
        deck.shuffle();

        // Deal 7 cards to each player
        for (Player player : players) {
            for (int i = 0; i < 7; i++) {
                player.drawCard(deck);
            }
        }

        // Start discard pile
        discardPile.push(deck.drawCard());
    }

    // Get current player
    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }

    // Move to next turn
    public void nextTurn() {
        currentPlayerIndex =
                (currentPlayerIndex + direction + players.size()) % players.size();
    }

    // Play one turn
    public void playTurn() {
        Player player = getCurrentPlayer();
        Card topCard = getTopCard();

        System.out.println(player.getName() + "'s turn. Top card: " + topCard);

        if (player.hasValidMove(topCard)) {
            Card played = player.playCard(topCard);

            if (played != null) {
                discardPile.push(played);
                System.out.println(player.getName() + " played: " + played);

                applyAction(played);
            }

        } else {
            System.out.println(player.getName() + " has no valid move. Drawing card...");
            player.drawCard(deck);
        }

        nextTurn();
    }

    // Apply action card effects
    private void applyAction(Card card) {
        if (card.getType().equalsIgnoreCase("action")) {

            switch (card.getValue().toLowerCase()) {

                case "skip":
                    System.out.println("Next player skipped!");
                    nextTurn();
                    break;

                case "reverse":
                    System.out.println("Direction reversed!");
                    direction *= -1;
                    break;

                case "draw2":
                    System.out.println("Next player draws 2 cards!");

                    int nextIndex =
                            (currentPlayerIndex + direction + players.size()) % players.size();

                    Player nextPlayer = players.get(nextIndex);

                    nextPlayer.drawCard(deck);
                    nextPlayer.drawCard(deck);

                    nextTurn();
                    break;
            }
        }
    }

    // Check winner
    public Player checkWinner() {
        for (Player player : players) {
            if (player.getHand().isEmpty()) {
                return player;
            }
        }
        return null;
    }

    // Get deck (for edu.utsa.cs3443.project_demo.controller)
    public Deck getDeck() {
        return deck;
    }

    // Get top card
    public Card getTopCard() {
        return discardPile.peek();
    }

    // Get discard pile
    public Stack<Card> getDiscardPile() {
        return discardPile;
    }

    // Get all players
    public ArrayList<Player> getPlayers() {
        return players;
    }
}