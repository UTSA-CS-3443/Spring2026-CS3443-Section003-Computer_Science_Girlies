package edu.utsa.cs3443.project_demo.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

import edu.utsa.cs3443.project_demo.model.Lobby;
import java.io.IOException;

public class LobbyController {

    @FXML private TextField playerNameField;
    @FXML private TextArea playerListArea;

    private Lobby lobby;

    @FXML
    public void initialize() {
        lobby = new Lobby(4); // max players
        updatePlayerList();
    }

    // Add player
    @FXML
    private void handleInvite(ActionEvent event) {
        String name = playerNameField.getText();

        if (!name.isEmpty()) {
            lobby.addPlayer(name);
            updatePlayerList();
            playerNameField.clear();
        }
    }

    // Start game
    @FXML
    private void handleStartGame(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/layouts/game.fxml"));

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Leave lobby
    @FXML
    private void handleLeaveLobby(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/layouts/main_menu.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update UI list
    private void updatePlayerList() {
        playerListArea.clear();

        for (String player : lobby.getPlayers()) {
            playerListArea.appendText(player + "\n");
        }
    }

    private void switchScene(ActionEvent event, String fxmlPath) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            double width = stage.getScene().getWidth();
            double height = stage.getScene().getHeight();

            Scene scene = new Scene(root, width, height);
            stage.setScene(scene);

            // Optional: keep maximized/fullscreen if already set
            stage.setMaximized(true);

            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handlePlayGame(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/lobby.fxml");
    }

    @FXML
    private void handleSettings(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/settings.fxml");
    }

    @FXML
    private void handleHowToPlay(ActionEvent event) {
        switchScene(event, "src/main/resources/layouts/how_to_play.fxml");
    }
}